fork from https://www.opencode.net/murkit

THE DOT v0.6

Copy Folder to /usr/share/icons



Copy to you'r Terminal, on you own Risk !

Open Terminal go to the Folder ware the README is and:
$ cp -r Dot-full-transparent /usr/share/icons

to remove
$ rm -R /usr/share/icons/Dot-full-transparent

